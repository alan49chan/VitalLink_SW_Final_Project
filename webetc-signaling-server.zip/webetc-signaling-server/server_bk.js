const express = require('express');
const http = require('http');
const socketIO = require('socket.io');
const cors = require('cors');

const app = express();
const server = http.createServer(app);
const io = socketIO(server, {
  cors: {
    origin: process.env.CORS_ORIGIN || '*',  // 生产环境应限制为你的域名
    methods: ['GET', 'POST'],
    credentials: true
  }
});

// 存储房间信息
const rooms = new Map();  // roomId -> Set of socketIds

app.use(cors());
app.use(express.json());

// 健康检查接口
app.get('/health', (req, res) => {
  res.json({ status: 'ok', rooms: rooms.size });
});

io.on('connection', (socket) => {
  console.log(`[${new Date().toISOString()}] Client connected: ${socket.id}`);

  // 1. 用户加入房间
  socket.on('join-room', (data) => {
    const { roomId, userName } = data;
    
    // 加入房间
    socket.join(roomId);
    socket.data = { roomId, userName, socketId: socket.id };
    
    // 初始化房间
    if (!rooms.has(roomId)) {
      rooms.set(roomId, new Map());  // Map of socketId -> userInfo
    }
    rooms.get(roomId).set(socket.id, { userName, socketId: socket.id });
    
    // 获取房间内其他用户
    const otherUsers = Array.from(rooms.get(roomId).entries())
      .filter(([id]) => id !== socket.id)
      .map(([id, info]) => ({
        socketId: id,
        userName: info.userName
      }));
    
    // 通知新用户：房间内现有用户列表
    socket.emit('existing-users', otherUsers);
    
    // 通知其他用户：新用户加入
    socket.to(roomId).emit('user-joined', {
      socketId: socket.id,
      userName: userName
    });
    
    console.log(`User ${userName} (${socket.id}) joined room: ${roomId}`);
  });

  // 2. WebRTC Offer (发起连接请求)
  socket.on('offer', (data) => {
    const { targetSocketId, offer } = data;
    socket.to(targetSocketId).emit('offer', {
      senderSocketId: socket.id,
      offer: offer
    });
  });

  // 3. WebRTC Answer (响应连接请求)
  socket.on('answer', (data) => {
    const { targetSocketId, answer } = data;
    socket.to(targetSocketId).emit('answer', {
      senderSocketId: socket.id,
      answer: answer
    });
  });

  // 4. ICE Candidate (网络候选地址交换)
  socket.on('ice-candidate', (data) => {
    const { targetSocketId, candidate } = data;
    socket.to(targetSocketId).emit('ice-candidate', {
      senderSocketId: socket.id,
      candidate: candidate
    });
  });

  // 5. 离开房间
  socket.on('leave-room', () => {
    const { roomId } = socket.data || {};
    if (roomId && rooms.has(roomId)) {
      rooms.get(roomId).delete(socket.id);
      socket.to(roomId).emit('user-left', { socketId: socket.id });
      
      // 如果房间为空，清理房间
      if (rooms.get(roomId).size === 0) {
        rooms.delete(roomId);
      }
    }
    socket.leave(roomId);
    console.log(`User ${socket.id} left room: ${roomId}`);
  });

  // 6. 断开连接
  socket.on('disconnect', () => {
    const { roomId, userName } = socket.data || {};
    if (roomId && rooms.has(roomId)) {
      rooms.get(roomId).delete(socket.id);
      socket.to(roomId).emit('user-left', { socketId: socket.id });
      
      if (rooms.get(roomId).size === 0) {
        rooms.delete(roomId);
      }
      console.log(`User ${userName || socket.id} disconnected from room: ${roomId}`);
    }
    console.log(`Client disconnected: ${socket.id}`);
  });
});

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  console.log(`Signaling server running on port ${PORT}`);
});
