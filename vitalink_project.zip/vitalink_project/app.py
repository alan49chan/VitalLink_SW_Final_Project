import streamlit as st
import pandas as pd
import sqlite3
from datetime import datetime
import plotly.express as px

# Database setup
conn = sqlite3.connect('vitalink.db', check_same_thread=False)
c = conn.cursor()
c.execute('''CREATE TABLE IF NOT EXISTS patients
             (id INTEGER PRIMARY KEY, name TEXT, glucose REAL, bp_systolic REAL, bp_diastolic REAL, heart_rate REAL, timestamp TEXT)''')
c.execute('''CREATE TABLE IF NOT EXISTS prescriptions
             (id INTEGER PRIMARY KEY, patient_name TEXT, medicine TEXT, dosage TEXT, notes TEXT, timestamp TEXT)''')
conn.commit()

st.set_page_config(page_title="VitalLink", page_icon="🩺", layout="wide")
st.title("🩺 VitalLink - Remote Chronic Care")
st.markdown("**Real WebRTC Video Consultation using our own Node.js Signaling Server + TURN**")

role = st.sidebar.selectbox("Select Role", ["Patient", "Doctor"])

ROOM_ID = "vitalink-demo-room"

if role == "Patient":
    st.header("🧑‍🦰 Patient Dashboard")
    name = st.text_input("Your Name", "Patient Paul")

    st.subheader("📡 Mock Sensor Data")
    col1, col2, col3 = st.columns(3)
    with col1: glucose = st.number_input("Blood Glucose (mg/dL)", 70, 300, 120)
    with col2:
        bp_s = st.number_input("BP Systolic", 90, 180, 130)
        bp_d = st.number_input("BP Diastolic", 60, 120, 85)
    with col3: hr = st.number_input("Heart Rate (bpm)", 50, 120, 75)

    if st.button("📡 Send Sensor Data"):
        ts = datetime.now().strftime("%Y-%m-%d %H:%M")
        c.execute("INSERT INTO patients (name, glucose, bp_systolic, bp_diastolic, heart_rate, timestamp) VALUES (?,?,?,?,?,?)",
                  (name, glucose, bp_s, bp_d, hr, ts))
        conn.commit()
        st.success(f"✅ Data sent at {ts}")

    st.subheader("Your Bio-Stat History")
    df = pd.read_sql(f"SELECT * FROM patients WHERE name='{name}' ORDER BY timestamp DESC", conn)
    if not df.empty:
        st.dataframe(df)
        fig = px.line(df, x='timestamp', y=['glucose', 'bp_systolic', 'heart_rate'], title="Trend Over Time")
        st.plotly_chart(fig, width='stretch')
    else:
        st.info("No data yet")

elif role == "Doctor":
    st.header("👨‍⚕️ Doctor Dashboard")
    df_all = pd.read_sql("SELECT * FROM patients ORDER BY timestamp DESC", conn)
    if not df_all.empty:
        st.dataframe(df_all)
        df_all['alert'] = df_all.apply(lambda row: "🔴 HIGH GLUCOSE!" if row['glucose'] > 180 else
                                      "🔴 HYPERTENSION!" if row['bp_systolic'] > 140 else "✅ Normal", axis=1)
        st.dataframe(df_all[['name', 'timestamp', 'alert']])

        patient_name = st.selectbox("Select Patient", df_all['name'].unique())
        patient_df = df_all[df_all['name'] == patient_name]
        st.plotly_chart(px.line(patient_df, x='timestamp', y=['glucose', 'bp_systolic', 'heart_rate']), width='stretch')

        st.subheader("💊 Assign Medicine")
        medicine = st.text_input("Medicine")
        dosage = st.text_input("Dosage")
        notes = st.text_area("Notes")
        if st.button("💊 Prescribe & Save"):
            ts = datetime.now().strftime("%Y-%m-%d %H:%M")
            c.execute("INSERT INTO prescriptions (patient_name, medicine, dosage, notes, timestamp) VALUES (?,?,?,?,?)",
                      (patient_name, medicine, dosage, notes, ts))
            conn.commit()
            st.success(f"✅ Prescription sent to {patient_name}!")

# ====================== CORRECTED WEBRTC CODE ======================
st.subheader("📹 Live Video Consultation Room")
st.caption(f"Room: **{ROOM_ID}** — Open two tabs (Patient + Doctor) and click Join")

# Status placeholder for Python-side updates
status_placeholder = st.empty()

html_code = f"""
<!DOCTYPE html>
<html>
<head>
    <script src="https://cdn.socket.io/4.7.5/socket.io.min.js"></script>
    <style>
        video {{ width: 100%; max-height: 420px; background: #111; border-radius: 8px; }}
        .container {{ display: flex; gap: 15px; flex-wrap: wrap; margin-top: 20px; }}
        button {{ padding: 12px 30px; font-size: 18px; margin: 10px 0; }}
        .status {{ padding: 10px; margin: 10px 0; border-radius: 5px; }}
        .status-info {{ background: #e3f2fd; color: #0d47a1; }}
        .status-error {{ background: #ffebee; color: #c62828; }}
        .status-success {{ background: #e8f5e9; color: #2e7d32; }}
    </style>
</head>
<body>
    <div>
        <button id="joinBtn">🎥 Join Video Call</button>
        <button id="leaveBtn" style="display:none;">❌ Leave Call</button>
        <div id="connectionStatus" class="status status-info">⚪ Not connected</div>
    </div>
    <div class="container">
        <div style="flex:1">
            <h4>📷 Your Camera</h4>
            <video id="localVideo" autoplay muted playsinline></video>
        </div>
        <div style="flex:1">
            <h4>👤 Remote Video</h4>
            <video id="remoteVideo" autoplay playsinline></video>
        </div>
    </div>

    <script>
        // Configuration
        const SOCKET_URL = "https://jojo988.com";
        const socket = io(SOCKET_URL, {{
            transports: ['websocket', 'polling'],
            reconnection: true,
            reconnectionAttempts: 5
        }});

        let localStream = null;
        let peerConnection = null;
        let currentTargetSocketId = null;
        let isInitiator = false;

        const roomId = "{ROOM_ID}";
        const userName = "{role}";

        const iceServers = [
            {{ urls: 'stun:stun.l.google.com:19302' }},
            {{ urls: 'stun:stun1.l.google.com:19302' }},
            {{ urls: 'stun:stun2.l.google.com:19302' }},
            {{ urls: 'stun:stun3.l.google.com:19302' }},
            {{ urls: 'stun:stun4.l.google.com:19302' }},
            {{
                urls: 'turn:turn.jojo988.com:3478',
                username: 'paul',
                credential: '66801224'
            }},
            {{
                urls: 'turns:jojo988.com:5349',
                username: 'paul',
                credential: '66801224'
            }}
        ];

        function updateStatus(message, type = 'info') {{
            const statusDiv = document.getElementById('connectionStatus');
            statusDiv.textContent = message;
            statusDiv.className = `status status-${{type}}`;
            console.log(`[Status] ${{message}}`);
        }}

        function createPeerConnection() {{
            if (peerConnection) {{
                peerConnection.close();
            }}

            peerConnection = new RTCPeerConnection({{ iceServers }});

            // Handle ICE candidates
            peerConnection.onicecandidate = (event) => {{
                if (event.candidate && currentTargetSocketId) {{
                    console.log('📡 Sending ICE candidate');
                    socket.emit("ice-candidate", {{
                        targetSocketId: currentTargetSocketId,
                        candidate: event.candidate
                    }});
                }}
            }};

            // Handle remote stream
            peerConnection.ontrack = (event) => {{
                console.log('🎥 Received remote stream');
                const remoteVideo = document.getElementById("remoteVideo");
                remoteVideo.srcObject = event.streams[0];
                updateStatus('Connected to peer!', 'success');
            }};

            // Handle connection state changes
            peerConnection.onconnectionstatechange = () => {{
                console.log(`🔌 Connection state: ${{peerConnection.connectionState}}`);
                if (peerConnection.connectionState === 'connected') {{
                    updateStatus('✅ Video call connected!', 'success');
                }} else if (peerConnection.connectionState === 'failed') {{
                    updateStatus('❌ Connection failed - check TURN server', 'error');
                }} else if (peerConnection.connectionState === 'disconnected') {{
                    updateStatus('⚠️ Connection lost', 'error');
                }}
            }};

            // Handle ICE connection state
            peerConnection.oniceconnectionstatechange = () => {{
                console.log(`🧊 ICE state: ${{peerConnection.iceConnectionState}}`);
                if (peerConnection.iceConnectionState === 'connected') {{
                    console.log('✅ ICE connected - direct or TURN');
                }} else if (peerConnection.iceConnectionState === 'failed') {{
                    console.log('❌ ICE failed');
                }}
            }};

            // Add local stream tracks if available
            if (localStream) {{
                localStream.getTracks().forEach(track => {{
                    peerConnection.addTrack(track, localStream);
                }});
            }}

            return peerConnection;
        }}

        async function initCall() {{
            const joinBtn = document.getElementById("joinBtn");
            const leaveBtn = document.getElementById("leaveBtn");

            joinBtn.disabled = true;
            joinBtn.textContent = "🎥 Requesting camera...";
            updateStatus('Requesting camera/microphone access...', 'info');

            try {{
                // Get user media
                localStream = await navigator.mediaDevices.getUserMedia({{
                    video: true,
                    audio: true
                }});
                document.getElementById("localVideo").srcObject = localStream;
                updateStatus('✅ Camera ready, joining room...', 'success');

                // Create peer connection
                createPeerConnection();

                // Join room
                socket.emit("join-room", {{ roomId, userName }});
                updateStatus('📡 Connecting to signaling server...', 'info');

                joinBtn.style.display = 'none';
                leaveBtn.style.display = 'inline-block';

            }} catch (err) {{
                console.error('Camera error:', err);
                updateStatus('❌ Cannot access camera/microphone. Please check permissions.', 'error');
                joinBtn.disabled = false;
                joinBtn.textContent = '🎥 Join Video Call';
            }}
        }}

        function leaveCall() {{
            updateStatus('Disconnecting...', 'info');

            if (peerConnection) {{
                peerConnection.close();
                peerConnection = null;
            }}

            if (localStream) {{
                localStream.getTracks().forEach(track => track.stop());
                localStream = null;
            }}

            document.getElementById("localVideo").srcObject = null;
            document.getElementById("remoteVideo").srcObject = null;

            socket.emit("leave-room");

            const joinBtn = document.getElementById("joinBtn");
            const leaveBtn = document.getElementById("leaveBtn");
            joinBtn.style.display = 'inline-block';
            leaveBtn.style.display = 'none';
            joinBtn.disabled = false;
            joinBtn.textContent = '🎥 Join Video Call';

            currentTargetSocketId = null;
            isInitiator = false;
            updateStatus('⚪ Disconnected', 'info');
        }}

        // Socket event handlers
        socket.on('connect', () => {{
            console.log('✅ Connected to signaling server');
            updateStatus('Connected to server', 'success');
        }});

        socket.on('disconnect', () => {{
            console.log('❌ Disconnected from signaling server');
            updateStatus('Disconnected from server', 'error');
        }});

        socket.on('existing-users', async (users) => {{
            console.log('Existing users in room:', users);
            if (users.length > 0 && peerConnection && !currentTargetSocketId) {{
                // Connect to the first user
                currentTargetSocketId = users[0].socketId;
                isInitiator = true;
                updateStatus('Creating connection to peer...', 'info');

                try {{
                    const offer = await peerConnection.createOffer();
                    await peerConnection.setLocalDescription(offer);
                    socket.emit("offer", {{
                        targetSocketId: currentTargetSocketId,
                        offer: peerConnection.localDescription
                    }});
                    updateStatus('Offer sent, waiting for answer...', 'info');
                }} catch (err) {{
                    console.error('Error creating offer:', err);
                    updateStatus('Error creating connection', 'error');
                }}
            }}
        }});

        socket.on('user-joined', async (data) => {{
            console.log('New user joined:', data);
            if (!currentTargetSocketId && peerConnection && isInitiator) {{
                currentTargetSocketId = data.socketId;
                updateStatus('New peer joined, connecting...', 'info');

                try {{
                    const offer = await peerConnection.createOffer();
                    await peerConnection.setLocalDescription(offer);
                    socket.emit("offer", {{
                        targetSocketId: currentTargetSocketId,
                        offer: peerConnection.localDescription
                    }});
                }} catch (err) {{
                    console.error('Error creating offer for new user:', err);
                }}
            }}
        }});

        socket.on('offer', async (data) => {{
            console.log('📞 Received offer from:', data.senderSocketId);
            if (!peerConnection) {{
                createPeerConnection();
            }}

            currentTargetSocketId = data.senderSocketId;
            isInitiator = false;

            try {{
                await peerConnection.setRemoteDescription(new RTCSessionDescription(data.offer));
                const answer = await peerConnection.createAnswer();
                await peerConnection.setLocalDescription(answer);
                socket.emit("answer", {{
                    targetSocketId: currentTargetSocketId,
                    answer: peerConnection.localDescription
                }});
                updateStatus('Answer sent, establishing connection...', 'info');
            }} catch (err) {{
                console.error('Error handling offer:', err);
                updateStatus('Error handling connection', 'error');
            }}
        }});

        socket.on('answer', async (data) => {{
            console.log('📞 Received answer from:', data.senderSocketId);
            try {{
                await peerConnection.setRemoteDescription(new RTCSessionDescription(data.answer));
                updateStatus('Connection established!', 'success');
            }} catch (err) {{
                console.error('Error handling answer:', err);
            }}
        }});

        socket.on('ice-candidate', async (data) => {{
            console.log('🧊 Received ICE candidate');
            if (peerConnection && data.candidate) {{
                try {{
                    await peerConnection.addIceCandidate(new RTCIceCandidate(data.candidate));
                }} catch (err) {{
                    console.error('Error adding ICE candidate:', err);
                }}
            }}
        }});

        socket.on('user-left', (data) => {{
            console.log('User left:', data);
            if (currentTargetSocketId === data.socketId) {{
                updateStatus('Peer disconnected', 'info');
                currentTargetSocketId = null;
                isInitiator = false;

                // Reset remote video
                document.getElementById("remoteVideo").srcObject = null;
            }}
        }});

        // Setup button handlers
        document.getElementById("joinBtn").addEventListener("click", initCall);
        document.getElementById("leaveBtn").addEventListener("click", leaveCall);
    </script>
</body>
</html>
"""

# Display WebRTC component
st.components.v1.html(html_code, height=700, width='stretch')

# Add WebRTC debugging info in sidebar
st.sidebar.success("✅ Using your Node.js Signaling Server + TURN (paul / 66801224)")
st.sidebar.info("""
**📋 WebRTC Connection Checklist:**
1. Both users must click "Join Video Call"
2. Allow camera/microphone permissions
3. Check browser console (F12) for ICE/TURN logs
4. If connection fails, TURN server is working as fallback
""")

st.caption("COMP2116 Final Project - Full custom WebRTC | Fixed: ICE candidates, connection states, and error handling")