const { io } = require("socket.io-client");
// Detailed connection test
const socket = io("https://jojo988.com", {
  transports: ['websocket', 'polling'],
  reconnection: false,
  timeout: 10000
});

socket.on('connect_error', (error) => {
  console.log('Error type:', error.type);
  console.log('Error message:', error.message);
  console.log('Error description:', error);
});

socket.on('connect_timeout', () => {
  console.log('Connection timeout');
});

socket.on('error', (error) => {
  console.log('Socket error:', error);
});