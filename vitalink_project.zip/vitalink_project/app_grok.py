import streamlit as st
import pandas as pd
import sqlite3
from datetime import datetime
import plotly.express as px

# Database setup
conn = sqlite3.connect('vitalink.db', check_same_thread=False)
c = conn.cursor()
c.execute('''CREATE TABLE IF NOT EXISTS patients
             (id INTEGER PRIMARY KEY, name TEXT, glucose REAL, bp_systolic REAL, bp_diastolic REAL, heart_rate REAL, timestamp TEXT)''')
c.execute('''CREATE TABLE IF NOT EXISTS prescriptions
             (id INTEGER PRIMARY KEY, patient_name TEXT, medicine TEXT, dosage TEXT, notes TEXT, timestamp TEXT)''')
conn.commit()

st.set_page_config(page_title="VitalLink", page_icon="🩺", layout="wide")
st.title("🩺 VitalLink - Remote Chronic Care")
st.markdown("**Real WebRTC Video Consultation using our own Node.js Signaling Server + TURN**")

role = st.sidebar.selectbox("Select Role", ["Patient", "Doctor"])

ROOM_ID = "vitalink-demo-room"

if role == "Patient":
    st.header("🧑‍🦰 Patient Dashboard")
    name = st.text_input("Your Name", "Patient Paul")

    st.subheader("📡 Mock Sensor Data")
    col1, col2, col3 = st.columns(3)
    with col1: glucose = st.number_input("Blood Glucose (mg/dL)", 70, 300, 120)
    with col2:
        bp_s = st.number_input("BP Systolic", 90, 180, 130)
        bp_d = st.number_input("BP Diastolic", 60, 120, 85)
    with col3: hr = st.number_input("Heart Rate (bpm)", 50, 120, 75)

    if st.button("📡 Send Sensor Data"):
        ts = datetime.now().strftime("%Y-%m-%d %H:%M")
        c.execute("INSERT INTO patients (name, glucose, bp_systolic, bp_diastolic, heart_rate, timestamp) VALUES (?,?,?,?,?,?)",
                  (name, glucose, bp_s, bp_d, hr, ts))
        conn.commit()
        st.success(f"✅ Data sent at {ts}")

    st.subheader("Your Bio-Stat History")
    df = pd.read_sql(f"SELECT * FROM patients WHERE name='{name}' ORDER BY timestamp DESC", conn)
    if not df.empty:
        st.dataframe(df)
        fig = px.line(df, x='timestamp', y=['glucose', 'bp_systolic', 'heart_rate'], title="Trend Over Time")
        st.plotly_chart(fig, width='stretch')
    else:
        st.info("No data yet")

elif role == "Doctor":
    st.header("👨‍⚕️ Doctor Dashboard")
    df_all = pd.read_sql("SELECT * FROM patients ORDER BY timestamp DESC", conn)
    if not df_all.empty:
        st.dataframe(df_all)
        df_all['alert'] = df_all.apply(lambda row: "🔴 HIGH GLUCOSE!" if row['glucose'] > 180 else
                                      "🔴 HYPERTENSION!" if row['bp_systolic'] > 140 else "✅ Normal", axis=1)
        st.dataframe(df_all[['name', 'timestamp', 'alert']])

        patient_name = st.selectbox("Select Patient", df_all['name'].unique())
        patient_df = df_all[df_all['name'] == patient_name]
        st.plotly_chart(px.line(patient_df, x='timestamp', y=['glucose', 'bp_systolic', 'heart_rate']), width='stretch')

        st.subheader("💊 Assign Medicine")
        medicine = st.text_input("Medicine")
        dosage = st.text_input("Dosage")
        notes = st.text_area("Notes")
        if st.button("💊 Prescribe & Save"):
            ts = datetime.now().strftime("%Y-%m-%d %H:%M")
            c.execute("INSERT INTO prescriptions (patient_name, medicine, dosage, notes, timestamp) VALUES (?,?,?,?,?)",
                      (patient_name, medicine, dosage, notes, ts))
            conn.commit()
            st.success(f"✅ Prescription sent to {patient_name}!")

# ====================== CUSTOM WEBRTC USING YOUR NODE.JS SERVER ======================
st.subheader("📹 Live Video Consultation Room")
st.caption(f"Room: **{ROOM_ID}** — Open two tabs (Patient + Doctor) and click Join")

html_code = f"""
<!DOCTYPE html>
<html>
<head>
    <script src="https://cdn.socket.io/4.7.5/socket.io.min.js"></script>
    <style>
        video {{ width: 100%; max-height: 420px; background: #111; border-radius: 8px; }}
        .container {{ display: flex; gap: 15px; flex-wrap: wrap; }}
        button {{ padding: 12px 30px; font-size: 18px; margin: 10px 0; }}
    </style>
</head>
<body>
    <button id="joinBtn">Join Video Call</button>
    <div class="container">
        <div>
            <h4>Your Camera</h4>
            <video id="localVideo" autoplay muted playsinline></video>
        </div>
        <div>
            <h4>Remote Video</h4>
            <video id="remoteVideo" autoplay playsinline></video>
        </div>
    </div>

    <script>
        const socket = io("https://jojo988.com");
        let localStream = null;
        let peerConnection = null;
        const roomId = "{ROOM_ID}";
        const userName = "{role}";
        let isInitiator = false;

        const iceServers = [
            {{ urls: 'stun:stun.l.google.com:19302' }},
            {{ urls: 'stun:stun1.l.google.com:19302' }},
            {{ urls: 'stun:stun2.l.google.com:19302' }},
            {{ urls: 'stun:stun3.l.google.com:19302' }},
            {{ urls: 'stun:stun4.l.google.com:19302' }},
            {{
                urls: 'turn:turn.jojo988.com:3478',
                username: 'paul',
                credential: '66801224'
            }},
            {{
                urls: 'turns:jojo988.com:5349',
                username: 'paul',
                credential: '66801224'
            }}
        ];

        function createPeerConnection() {{
            peerConnection = new RTCPeerConnection({{ iceServers }});

            peerConnection.onicecandidate = (event) => {{
                if (event.candidate) {{
                    socket.emit("ice-candidate", {{ targetSocketId: null, candidate: event.candidate }});
                }}
            }};

            peerConnection.ontrack = (event) => {{
                document.getElementById("remoteVideo").srcObject = event.streams[0];
            }};
        }}

        document.getElementById("joinBtn").addEventListener("click", async () => {{
            const btn = document.getElementById("joinBtn");
            btn.disabled = true;
            btn.textContent = "Connecting...";

            try {{
                localStream = await navigator.mediaDevices.getUserMedia({{ video: true, audio: true }});
                document.getElementById("localVideo").srcObject = localStream;

                createPeerConnection();

                localStream.getTracks().forEach(track => peerConnection.addTrack(track, localStream));

                socket.emit("join-room", {{ roomId, userName }});

                // Existing users → I am the initiator
                socket.on("existing-users", (users) => {{
                    if (users.length > 0) {{
                        isInitiator = true;
                        peerConnection.createOffer()
                            .then(offer => peerConnection.setLocalDescription(offer))
                            .then(() => {{
                                socket.emit("offer", {{ targetSocketId: users[0].socketId, offer: peerConnection.localDescription }});
                            }});
                    }}
                }});

                socket.on("user-joined", (data) => {{
                    // New user joined → create answer if I am initiator
                    if (isInitiator) {{
                        peerConnection.createOffer()
                            .then(offer => peerConnection.setLocalDescription(offer))
                            .then(() => {{
                                socket.emit("offer", {{ targetSocketId: data.socketId, offer: peerConnection.localDescription }});
                            }});
                    }}
                }});

                socket.on("offer", (data) => {{
                    peerConnection.setRemoteDescription(data.offer)
                        .then(() => peerConnection.createAnswer())
                        .then(answer => peerConnection.setLocalDescription(answer))
                        .then(() => {{
                            socket.emit("answer", {{ targetSocketId: data.senderSocketId, answer: peerConnection.localDescription }});
                        }});
                }});

                socket.on("answer", (data) => {{
                    peerConnection.setRemoteDescription(data.answer);
                }});

                socket.on("ice-candidate", (data) => {{
                    if (data.candidate) peerConnection.addIceCandidate(data.candidate);
                }});

                st.success("✅ Connected to your Node.js signaling server!");

            }} catch (err) {{
                console.error(err);
                alert("Camera/Microphone access denied or error");
            }}
        }});
    </script>
</body>
</html>
"""

st.iframe(html_code, height=720, width='stretch')

st.sidebar.success("✅ Using your Node.js Signaling Server + TURN (paul / 66801224)")
st.caption("COMP2116 Final Project - Full custom WebRTC")
