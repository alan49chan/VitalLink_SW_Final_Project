import streamlit as st
import pandas as pd
import sqlite3
from datetime import datetime
import plotly.express as px
import base64

# Database setup
conn = sqlite3.connect('vitalink.db', check_same_thread=False)
c = conn.cursor()
c.execute('''CREATE TABLE IF NOT EXISTS patients
             (id INTEGER PRIMARY KEY, name TEXT, glucose REAL, bp_systolic REAL, bp_diastolic REAL, heart_rate REAL, timestamp TEXT)''')
c.execute('''CREATE TABLE IF NOT EXISTS prescriptions
             (id INTEGER PRIMARY KEY, patient_name TEXT, medicine TEXT, dosage TEXT, notes TEXT, timestamp TEXT)''')
conn.commit()

st.set_page_config(page_title="VitalLink", page_icon="🩺", layout="wide")
st.title("🩺 VitalLink - Remote Chronic Care")
st.markdown("**Real WebRTC Video Consultation using our own Node.js Signaling Server + TURN**")

role = st.sidebar.selectbox("Select Role", ["Patient", "Doctor"])

ROOM_ID = "vitalink-demo-room"

if role == "Patient":
    st.header("🧑‍🦰 Patient Dashboard")
    name = st.text_input("Your Name", "Patient Paul")

    st.subheader("📡 Mock Sensor Data")
    col1, col2, col3 = st.columns(3)
    with col1:
        glucose = st.number_input("Blood Glucose (mg/dL)", 70, 300, 120)
    with col2:
        bp_s = st.number_input("BP Systolic", 90, 180, 130)
        bp_d = st.number_input("BP Diastolic", 60, 120, 85)
    with col3:
        hr = st.number_input("Heart Rate (bpm)", 50, 120, 75)

    if st.button("📡 Send Sensor Data"):
        ts = datetime.now().strftime("%Y-%m-%d %H:%M")
        c.execute("INSERT INTO patients (name, glucose, bp_systolic, bp_diastolic, heart_rate, timestamp) VALUES (?,?,?,?,?,?)",
                  (name, glucose, bp_s, bp_d, hr, ts))
        conn.commit()
        st.success(f"✅ Data sent at {ts}")

    st.subheader("Your Bio-Stat History")
    df = pd.read_sql(f"SELECT * FROM patients WHERE name='{name}' ORDER BY timestamp DESC", conn)
    if not df.empty:
        st.dataframe(df)
        fig = px.line(df, x='timestamp', y=['glucose', 'bp_systolic', 'heart_rate'], title="Trend Over Time")
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("No data yet")

elif role == "Doctor":
    st.header("👨‍⚕️ Doctor Dashboard")
    df_all = pd.read_sql("SELECT * FROM patients ORDER BY timestamp DESC", conn)
    if not df_all.empty:
        st.dataframe(df_all)
        df_all['alert'] = df_all.apply(lambda row: "🔴 HIGH GLUCOSE!" if row['glucose'] > 180 else
                                      "🔴 HYPERTENSION!" if row['bp_systolic'] > 140 else "✅ Normal", axis=1)
        st.dataframe(df_all[['name', 'timestamp', 'alert']])

        patient_name = st.selectbox("Select Patient", df_all['name'].unique())
        patient_df = df_all[df_all['name'] == patient_name]
        st.plotly_chart(px.line(patient_df, x='timestamp', y=['glucose', 'bp_systolic', 'heart_rate']), use_container_width=True)

        st.subheader("💊 Assign Medicine")
        medicine = st.text_input("Medicine")
        dosage = st.text_input("Dosage")
        notes = st.text_area("Notes")
        if st.button("💊 Prescribe & Save"):
            ts = datetime.now().strftime("%Y-%m-%d %H:%M")
            c.execute("INSERT INTO prescriptions (patient_name, medicine, dosage, notes, timestamp) VALUES (?,?,?,?,?)",
                      (patient_name, medicine, dosage, notes, ts))
            conn.commit()
            st.success(f"✅ Prescription sent to {patient_name}!")

# ====================== CUSTOM WEBRTC USING YOUR NODE.JS SERVER ======================
st.subheader("📹 Live Video Consultation Room")
st.caption(f"Room: **{ROOM_ID}** — Open two tabs (Patient + Doctor) and click Join")

html_code = f"""
<!DOCTYPE html>
<html>
<head>
    <script src="https://cdn.socket.io/4.7.5/socket.io.min.js"></script>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; padding: 10px; }}
        .status {{
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            text-align: center;
            font-weight: bold;
        }}
        .status.connected {{ background: #d4edda; color: #155724; }}
        .status.disconnected {{ background: #f8d7da; color: #721c24; }}
        .status.connecting {{ background: #fff3cd; color: #856404; }}
        button {{
            width: 100%;
            padding: 12px 30px;
            font-size: 18px;
            margin: 10px 0;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }}
        button:hover:not(:disabled) {{ background-color: #45a049; }}
        button:disabled {{ background-color: #cccccc; cursor: not-allowed; }}
        .container {{ display: flex; gap: 15px; flex-wrap: wrap; margin-top: 10px; }}
        .video-container {{
            flex: 1;
            min-width: 300px;
            position: relative;
        }}
        .video-container h4 {{
            margin-bottom: 10px;
            color: #333;
        }}
        video {{
            width: 100%;
            max-height: 420px;
            background: #111;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }}
        @media (max-width: 768px) {{
            .container {{ flex-direction: column; }}
        }}
        .debug {{
            font-size: 12px;
            color: #666;
            margin-top: 10px;
            padding: 10px;
            background: #f5f5f5;
            border-radius: 5px;
            font-family: monospace;
            max-height: 150px;
            overflow-y: auto;
        }}
    </style>
</head>
<body>
    <button id="joinBtn">🎥 Join Video Call</button>
    <div id="status" class="status disconnected">⚫ Disconnected</div>
    <div class="container">
        <div class="video-container">
            <h4>📹 Your Camera</h4>
            <video id="localVideo" autoplay muted playsinline></video>
        </div>
        <div class="video-container">
            <h4>👤 Remote Video</h4>
            <video id="remoteVideo" autoplay playsinline></video>
        </div>
    </div>
    <div class="debug" id="debug"></div>

    <script>
        // Connect to the same origin (uses current page's protocol and host)
        // This will work through Nginx proxy automatically
        const socket = io({{
            path: '/socket.io',
            transports: ['websocket', 'polling'],
            reconnection: true,
            reconnectionAttempts: 5,
            reconnectionDelay: 1000
        }});

        let localStream = null;
        let peerConnection = null;
        const roomId = "{ROOM_ID}";
        let mySocketId = null;

        const statusDiv = document.getElementById('status');
        const debugDiv = document.getElementById('debug');

        function logDebug(message) {{
            const timestamp = new Date().toLocaleTimeString();
            console.log(`[${{timestamp}}] ${{message}}`);
            debugDiv.innerHTML += `[${{timestamp}}] ${{message}}<br>`;
            debugDiv.scrollTop = debugDiv.scrollHeight;
        }}

        function updateStatus(message, type) {{
            statusDiv.innerHTML = message;
            statusDiv.className = `status ${{type}}`;
            logDebug(`Status: ${{message}}`);
        }}

        // Socket event handlers
        socket.on('connect', () => {{
            mySocketId = socket.id;
            updateStatus('✅ Connected to signaling server', 'connected');
            logDebug('Socket ID: ' + mySocketId);
        }});

        socket.on('connect_error', (error) => {{
            logDebug('❌ Connection error: ' + error.message);
            updateStatus('❌ Connection error: ' + error.message, 'disconnected');
        }});

        socket.on('disconnect', () => {{
            updateStatus('⚠️ Disconnected from signaling server', 'disconnected');
            logDebug('Socket disconnected');
        }});

        socket.on('existing-users', (users) => {{
            logDebug('Existing users in room: ' + JSON.stringify(users));
            if (users && users.length > 0 && peerConnection) {{
                updateStatus('📞 Initiating call...', 'connecting');
                createOffer();
            }} else {{
                updateStatus('📞 Waiting for other user to join...', 'connecting');
            }}
        }});

        socket.on('user-joined', (data) => {{
            logDebug('User joined: ' + JSON.stringify(data));
            if (peerConnection) {{
                updateStatus('📞 User joined, initiating call...', 'connecting');
                createOffer();
            }}
        }});

        socket.on('user-left', (data) => {{
            logDebug('User left: ' + JSON.stringify(data));
            if (peerConnection) {{
                peerConnection.close();
                peerConnection = null;
                document.getElementById('remoteVideo').srcObject = null;
                updateStatus('📞 Peer left, waiting for reconnection...', 'connecting');
            }}
        }});

        socket.on('offer', async (data) => {{
            logDebug('Received offer from: ' + data.senderSocketId);
            if (!peerConnection) createPeerConnection();
            try {{
                await peerConnection.setRemoteDescription(new RTCSessionDescription(data.offer));
                const answer = await peerConnection.createAnswer();
                await peerConnection.setLocalDescription(answer);
                socket.emit('answer', {{
                    targetSocketId: data.senderSocketId,
                    answer: peerConnection.localDescription
                }});
                logDebug('Answer sent');
            }} catch (error) {{
                logDebug('Error handling offer: ' + error.message);
            }}
        }});

        socket.on('answer', (data) => {{
            logDebug('Received answer');
            if (peerConnection) {{
                peerConnection.setRemoteDescription(new RTCSessionDescription(data.answer))
                    .catch(err => logDebug('Error setting answer: ' + err.message));
            }}
        }});

        socket.on('ice-candidate', (data) => {{
            logDebug('Received ICE candidate');
            if (data.candidate && peerConnection) {{
                peerConnection.addIceCandidate(new RTCIceCandidate(data.candidate))
                    .catch(err => logDebug('Error adding ICE candidate: ' + err.message));
            }}
        }});

        const iceServers = [
            {{ urls: 'stun:stun.l.google.com:19302' }},
            {{ urls: 'stun:stun1.l.google.com:19302' }},
            {{ urls: 'stun:stun2.l.google.com:19302' }},
            {{ urls: 'stun:stun3.l.google.com:19302' }},
            {{ urls: 'stun:stun4.l.google.com:19302' }},
            {{
                urls: 'turn:turn.jojo988.com:3478',
                username: 'paul',
                credential: '66801224'
            }},
            {{
                urls: 'turns:jojo988.com:5349',
                username: 'paul',
                credential: '66801224'
            }}
        ];

        function createPeerConnection() {{
            logDebug('Creating PeerConnection...');
            peerConnection = new RTCPeerConnection({{ iceServers: iceServers }});

            peerConnection.onicecandidate = (event) => {{
                if (event.candidate) {{
                    logDebug('Sending ICE candidate');
                    socket.emit('ice-candidate', {{
                        targetSocketId: null,
                        candidate: event.candidate
                    }});
                }}
            }};

            peerConnection.oniceconnectionstatechange = () => {{
                logDebug('ICE Connection State: ' + peerConnection.iceConnectionState);
                if (peerConnection.iceConnectionState === 'connected') {{
                    updateStatus('✅ Connected - Video streaming', 'connected');
                }} else if (peerConnection.iceConnectionState === 'failed') {{
                    updateStatus('❌ Connection failed - check TURN server', 'disconnected');
                }}
            }};

            peerConnection.ontrack = (event) => {{
                logDebug('Received remote track');
                const remoteVideo = document.getElementById('remoteVideo');
                remoteVideo.srcObject = event.streams[0];
                updateStatus('✅ Connected - Video streaming active', 'connected');
            }};

            if (localStream) {{
                localStream.getTracks().forEach(track => {{
                    peerConnection.addTrack(track, localStream);
                    logDebug('Added track: ' + track.kind);
                }});
            }}
        }}

        async function createOffer() {{
            try {{
                const offer = await peerConnection.createOffer();
                await peerConnection.setLocalDescription(offer);
                socket.emit('offer', {{
                    targetSocketId: null,
                    offer: peerConnection.localDescription
                }});
                logDebug('Offer sent');
            }} catch (error) {{
                logDebug('Error creating offer: ' + error.message);
            }}
        }}

        document.getElementById('joinBtn').addEventListener('click', async () => {{
            const btn = document.getElementById('joinBtn');
            btn.disabled = true;
            btn.textContent = 'Connecting...';

            try {{
                updateStatus('🎥 Requesting camera/microphone...', 'connecting');
                localStream = await navigator.mediaDevices.getUserMedia({{
                    video: true,
                    audio: true
                }});
                document.getElementById('localVideo').srcObject = localStream;
                logDebug('Got local stream');

                updateStatus('📡 Creating connection...', 'connecting');
                createPeerConnection();

                // Join the room
                socket.emit('join-room', {{
                    roomId: roomId,
                    userName: '{role}'
                }});
                logDebug('Joined room: ' + roomId);

                btn.textContent = '✅ Connected';
                updateStatus('🟢 Connected - Waiting for peer...', 'connected');

            }} catch (err) {{
                logDebug('Error: ' + err.message);
                alert('Error: ' + err.message);
                btn.disabled = false;
                btn.textContent = '🎥 Join Video Call';
                updateStatus('❌ Error: ' + err.message, 'disconnected');
            }}
        }});

        window.addEventListener('beforeunload', () => {{
            if (localStream) {{
                localStream.getTracks().forEach(track => track.stop());
            }}
            if (peerConnection) {{
                peerConnection.close();
            }}
            if (socket) {{
                socket.emit('leave-room', {{ roomId: roomId }});
                socket.disconnect();
            }}
        }});
    </script>
</body>
</html>
"""

# Encode HTML to base64 to avoid deprecation warning
html_base64 = base64.b64encode(html_code.encode()).decode()

# Use st.iframe with data URL
st.iframe(f"data:text/html;base64,{html_base64}", height=750, width='stretch')

st.sidebar.success("✅ Using your Node.js Signaling Server + TURN (paul / 66801224)")
st.sidebar.info("📌 **Instructions:**\n1. Open two browser tabs\n2. Set one as Patient, one as Doctor\n3. Click 'Join Video Call' in both tabs\n4. Allow camera/microphone access\n5. Check debug console for connection status")

st.sidebar.warning("⚠️ **Troubleshooting:**\n- Make sure Node.js server is running: `sudo systemctl status vitallink.service`\n- Check Nginx WebSocket proxy configuration\n- Verify TURN server is accessible\n- Open browser console (F12) for detailed errors")
st.caption("COMP2116 Final Project - Full custom WebRTC with Node.js Signaling Server")